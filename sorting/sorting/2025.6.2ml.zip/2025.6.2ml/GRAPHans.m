s = [1 2] %start nodes
t = [2 3] %end nodes
G = graph(s, t); %create a graph object
plog(G);
title('Graph'); %ADD A TITLE