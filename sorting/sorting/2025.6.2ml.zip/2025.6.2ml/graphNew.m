G = graph([1 2], [2 3]); %edges: 1-2 and
plot(G);
title('Undirected Graph');

GH = digraph